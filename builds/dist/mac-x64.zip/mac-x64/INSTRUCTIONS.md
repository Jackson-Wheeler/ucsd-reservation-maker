# ucsd-reservation-maker
Utilizes Selenium to make UCSD room reservations on the browser as defined by configuration files
